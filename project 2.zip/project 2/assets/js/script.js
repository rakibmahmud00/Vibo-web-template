new WOW().init();

$(document).ready(function () {

   $(".single-app-dtl").click(function () {

      $('#dtls-p').slideToggle(300);
      $('#dtls-p').css({ "color": "#FFF", "font-weight": "#FFF" });
      $(this).toggleClass("togdlt");
   })

   $(".single-app-dtl2").click(function () {

      $('#dtls-p2').slideToggle(300);
      $('#dtls-p2').css({ "color": "#FFF", "font-weight": "#FFF" });
      $(this).toggleClass("togdlt");
   })

   $(".single-app-dtl3").click(function () {

      $('#dtls-p3').slideToggle(300);
      $('#dtls-p3').css({ "color": "#FFF", "font-weight": "#FFF" });
      $(this).toggleClass("togdlt");
   })

   $(".single-app-dtl4").click(function () {

      $('#dtls-p4').slideToggle(300);
      $('#dtls-p4').css({ "color": "#FFF", "font-weight": "#FFF" });
      $(this).toggleClass("togdlt");
   })

   $(window).click(function () {
      $('.mobile-menu-area').removeClass('menu-remove');
      $('.mobile-menu-area').addClass('menu-remove');
   });

   $(window).scroll(function () {
      $('.mobile-menu-area').removeClass('menu-remove');
      $('.mobile-menu-area').addClass('menu-remove');
   });

   $('.burger').click(function () {
      $('.mobile-menu-area').toggleClass('menu-remove');
      return false;
   });


});
